<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Home | WebprogrammingUNPAS'

        ];
        echo view('Layout/header', $data);
        echo view('pages/home');
        echo view('Layout/footer');
    }


    public function about()
    {
        $data = [
            'title' => 'About Me'

        ];
        echo view('Layout/header', $data);
        echo view('pages/about');
        echo view('Layout/footer');
    }


    //--------------------------------------------------------------------

}
