<div class="ontainer">
    <div class="row">
        <div class="col">

            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora nihil rem optio neque odio sunt? Corporis tenetur, necessitatibus, dolor, aliquam praesentium accusamus aperiam eos impedit alias eaque ducimus. Odio, eveniet.</p>

        </div>
    </div>
</div>